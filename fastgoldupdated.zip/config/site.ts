export const siteConfig = {
  name: "Fast Gold Africa",
  url: "http://fastgoldafrica.com",
  description: "Fast Gold Africa is your reliable gold trading partner",
  author: "Fast Gold Africa",
  links: {
    twitter: "",
    facebook: "",
    instagram: "",
    youtube: "",
    linkedin: "",
  },
};

export type SiteConfig = typeof siteConfig;
