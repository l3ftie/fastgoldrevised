import React from "react";

const SiteFooter = () => {
  return <div>SiteFooter</div>;
};

export default SiteFooter;
