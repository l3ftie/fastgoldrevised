export const mainLinks = [
  {
    id: 1,
    linkName: "Home",
    to: "home",
  },
  {
    id: 2,
    linkName: "About Us",
    to: "about",
  },
  {
    id: 3,
    linkName: "How it works",
    to: "howitworks",
  },
  {
    id: 4,
    linkName: "Contact Us",
    to: "contact",
  },
];
