export const branches = [
  {
    id: 1,
    title: "Pretoria",
    country: "South Africa",
    contact: "+27789247007",
  },
  {
    id: 2,
    title: "Durban",
    country: "South Africa",
    contact: "+27789247007",
  },
  {
    id: 3,
    title: "Kampala",
    country: "Uganda",
    contact: "+256 779 374 175",
  },
  {
    id: 4,
    title: "DR Congo",
    country: "Kivu",
    contact: "+256 779 374 175",
  },
  {
    id: 5,
    title: "Sierra Leon",
    country: "Freetown",
    contact: "+256 779 374 175",
  },
];
